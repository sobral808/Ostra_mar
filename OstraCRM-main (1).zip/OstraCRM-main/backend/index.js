const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = process.env.PORT || 4000;

app.use(cors());
app.use(bodyParser.json());

let pescadores = [
  { id: 1, nome: 'João da Costa', cpf: '123.456.789-00', telefone: '(81) 99999-0000', endereco: 'R. do Mar, 12' },
  { id: 2, nome: 'Maria das Ostras', cpf: '987.654.321-00', telefone: '(81) 98888-1111', endereco: 'R. da Praia, 45' }
];

app.get('/api/pescadores', (req, res) => {
  res.json(pescadores);
});

app.post('/api/pescadores', (req, res) => {
  const { nome, cpf, telefone, endereco } = req.body;
  if (!nome || !cpf) {
    return res.status(400).json({ error: 'Nome e CPF são obrigatórios' });
  }

  const novoPescador = {
    id: pescadores.length + 1,
    nome,
    cpf,
    telefone: telefone || '',
    endereco: endereco || ''
  };

  pescadores.push(novoPescador);
  res.status(201).json(novoPescador);
});

app.listen(port, () => {
  console.log(`OstraCRM backend rodando em http://localhost:${port}`);
});
